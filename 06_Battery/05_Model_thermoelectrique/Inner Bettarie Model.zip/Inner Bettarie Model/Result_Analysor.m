s=input('Number of cells in serie :   ');
p=floor(size(out.temperature.Data,2)/s);
figure;
subplot(1,2,1);out.temperature.Name='Temperature(^oC)';
plot(out.temperature);legend;
title("Evolution of each cell's Temperature");
subplot(1,2,2);out.soc.Name='SOC(.)';
plot(out.soc);legend;
title("Evolution of each cell's SOC(State of Charge)");
figure;
subplot(1,2,1);out.Power.Name='Power(kW)';
plot(out.Power);title("Evolution of total power");
subplot(1,2,2);out.ocv.Name='Voltage';
plot(out.ocv);title("Evolution of total voltage");
figure;
subplot(1,2,1);title("Final distribution of temperature");
tem = reshape(out.temperature.Data(size(out.temperature.Data,1),:),s,p);
contourf(tem,'ShowText','on')
subplot(1,2,2);title("Final distribution of SOC");
soc = reshape(out.soc.Data(size(out.soc.Data,1),:),s,p);
if max(max(soc)) == min(min(soc))
    soc(1,1)=soc(1,1)-1e-12;
    contourf(soc,0:1,'ShowText','on')
else
    contourf(soc,'ShowText','on')
end