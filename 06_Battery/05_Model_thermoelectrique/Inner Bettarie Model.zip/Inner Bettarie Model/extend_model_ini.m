ssc_build EpsaSimscape;
EpsaSimscape_lib;
cell_prop = data_load('Cell_data.xlsx')
